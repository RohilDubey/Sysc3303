
public class WriteAccessException extends Exception{
	public WriteAccessException(String message){
		super(message);
	}
}
